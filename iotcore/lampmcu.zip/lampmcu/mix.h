#ifndef	_MIX_H
#define	_MIX_H

#include "SWM201.h"


extern	void colormix(int r,int g, int b,int reslut[5]);
extern	void colormixsimple(int r, int g, int b, int c[5]);

#endif
