#include "SWM201.h"
#include "sm15155e.h"

//#define	USE_TIMER0
#define	USE_PWM0


#ifdef	USE_PWM0
uint32_t	duty_zero;
uint32_t	period_zero;

//uint32_t	smTimer = 1000 * 3;
//uint8_t		flash_a = 50;

uint8_t		read_bit;
uint8_t		read_cnt;

#define		LAMP_MAX	5


#define		DUTY_VALUE_0		18//18
#define		DUTY_VALUE_1		54//56
#define		PERIOD_VALUE		75//75

uint8_t	rgbwy_data[10] = {0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0x12, 0x34, 0x56, 0x78};
uint8_t	control_data[4] = {0x21, 0x08, 0x42, 0x00};

uint8_t	update_data80[80];
uint8_t	update_data32[32];
uint8_t	update_data[10 * LAMP_MAX + 4];

static void Sm15155eInitPwm(uint16_t period, uint16_t duty) {
	PWM_InitStructure  PWM_initStruct;
	
	PORT_Init(PORTM, PIN9, PORTM_PIN9_PWM0B,  0);	
	PORT_Init(PORTA, PIN2, PORTA_PIN2_PWM0AN, 0);
	PORT_Init(PORTA, PIN6, PORTA_PIN6_PWM0B,  0);
	PORT_Init(PORTA, PIN7, PORTA_PIN7_PWM0BN, 0);
	
	PWM_initStruct.Mode = PWM_EDGE_ALIGNED;
	PWM_initStruct.Clkdiv = 1;					//	F_PWM = 60M/1 = 60M	
	PWM_initStruct.Period = period;				//	60M/75 = 800kHz,
	PWM_initStruct.HdutyA =  duty;				//	duty / period
	PWM_initStruct.DeadzoneA = 0;				//
	PWM_initStruct.IdleLevelA = 0;
	PWM_initStruct.IdleLevelAN= 0;
	PWM_initStruct.OutputInvA = 0;
	PWM_initStruct.OutputInvAN= 0;
	PWM_initStruct.HdutyB =  duty;				//	duty / period
	PWM_initStruct.DeadzoneB = 0;				//
	PWM_initStruct.IdleLevelB = 0;
	PWM_initStruct.IdleLevelBN= 0;
	PWM_initStruct.OutputInvB = 0;
	PWM_initStruct.OutputInvBN= 0;
	PWM_initStruct.UpOvfIE    = 1;
	PWM_initStruct.DownOvfIE  = 0;
	PWM_initStruct.UpCmpAIE   = 0;
	PWM_initStruct.DownCmpAIE = 0;
	PWM_initStruct.UpCmpBIE   = 0;
	PWM_initStruct.DownCmpBIE = 0;
	PWM_Init(PWM0, &PWM_initStruct);

	//PWM_ReloadEn(PWM0_MSK);
	
	//PWM_Start(PWM0_MSK);
	
	//Sm15155eStart();
}

void Sm15155Init(void) {
	
	period_zero = PERIOD_VALUE;
	duty_zero = DUTY_VALUE_0;	
	Sm15155eInitPwm(period_zero, duty_zero);
}

void Sm15155eReaload(uint16_t duty) {
	PWM_ReloadDis(PWM0_MSK);
	PWM0->CMPA  = duty;
	PWM0->CMPB  = duty;
	PWM_ReloadEn(PWM0_MSK);
}
	
void Sm15155eUpdateData(uint32_t bright, uint32_t color) {
	uint16_t	r, g, b, w, y;
	uint8_t	i;
	uint8_t	ind;
	
#if 1
	r = ((color >> 16) & 0xFF) * 256;
	g = ((color >> 8) & 0xFF) * 256;
	b = ((color) & 0xFF) * 256;
	w = bright * 0xFFFF / 100;
	y = 0x8000;
#else
	r = ((color >> 16) & 0xFF) * 1;
	g = ((color >> 8) & 0xFF) * 1;
	b = ((color) & 0xFF) * 1;
	w = bright * 0xFF / 100;
	y = 0x80;
#endif
	
	ind = 0;
	for (i = 0; i < LAMP_MAX; i++) {
		update_data[i * 10 + 0] = (r >> 8) & 0xFF;
		update_data[i * 10 + 1] = (r >> 0) & 0xFF;
		update_data[i * 10 + 2] = (g >> 8) & 0xFF;
		update_data[i * 10 + 3] = (g >> 0) & 0xFF;
		update_data[i * 10 + 4] = (b >> 8) & 0xFF;
		update_data[i * 10 + 5] = (b >> 0) & 0xFF;
		update_data[i * 10 + 6] = (w >> 8) & 0xFF;
		update_data[i * 10 + 7] = (w >> 0) & 0xFF;
		update_data[i * 10 + 8] = (y >> 8) & 0xFF;
		update_data[i * 10 + 9] = (y >> 0) & 0xFF;
	}

	ind = 10 * LAMP_MAX;
	update_data[ind++] = control_data[0];
	update_data[ind++] = control_data[1];
	update_data[ind++] = control_data[2];
	update_data[ind++] = control_data[3];
	

	read_bit = 7;
	read_cnt = 0;
	
	Sm15155eStart();
	
#if 0	
	uint8_t	i;
	uint8_t	ind;
	
	ind = 0;
	for (i = 0; i < 10; i++) {
		update_data[ind++] = rgbwy_data[i] + flash_a;
	}
	update_data[ind++] = control_data[0];
	update_data[ind++] = control_data[1];
	update_data[ind++] = control_data[2];
	update_data[ind++] = control_data[3];
	
	read_bit = 7;
	read_cnt = 0;
	
	flash_a += 0x50;
#endif	
}

void Sm15155eStart(void) {
	PWM_Start(PWM0_MSK);
}

void Sm15155eStop(void) {
	PWM_Stop(PWM0_MSK);
}

void PWM0_Handler(void)
{
	if(PWM_IntStat(PWM0, PWM_IT_OVF_UP))
	{
		PWM_IntClr(PWM0, PWM_IT_OVF_UP);
#if 1
		if (read_cnt < LAMP_MAX * 10 + 4) {
			if ((1<<read_bit) & update_data[read_cnt]) {
				duty_zero = DUTY_VALUE_1;
			}
			else {
				duty_zero = DUTY_VALUE_0;
			}
			Sm15155eReaload(duty_zero);
			
			if (read_bit) {
				read_bit--;
			}
			else {
				read_bit = 7;
				read_cnt++;
				if (read_cnt >= LAMP_MAX * 10 + 4) {
					//read_cnt = 0;
					Sm15155eStop();
				}
			}			
		}	
#endif	

	}
	
/*	
	if(PWM_IntStat(PWM0, PWM_IT_CMPA_UP))
	{
		PWM_IntClr(PWM0, PWM_IT_CMPA_UP);
	}
	if(PWM_IntStat(PWM0, PWM_IT_CMPB_UP))
	{
		PWM_IntClr(PWM0, PWM_IT_CMPB_UP);		
	}
*/
}

#endif


#ifdef	USE_TIMER0
#define	SM_PORT		PORTA
#define	SM_PIN		PIN14
#define	SM_FUNC		PORTA_PIN14_TIMR0_OUT

uint32_t	rate;


void Sm15155Init(void) {
	//uint32_t t = SystemCoreClock;
	PORT_Init(SM_PORT, SM_PIN, SM_FUNC, 0);
	
	
	TIMR_Init(TIMR0, TIMR_MODE_OC, CyclesPerUs / 100, 125, 0);	/// CyclesPerUs = SystemCoreClock / 1000000, m = 1/1000000/100*125 = 1/800000  800KHz
	
	TIMR_OC_Init(TIMR0, 25, 1, 1);						// 25/125 = 25%
	
	rate = 25;
}

void Sm15155eStart(void) {
	
	TIMR_Start(TIMR0);	
}

void Sm15155eStop(void) {
	
	TIMR_Stop(TIMR0);	
}

void TIMR0_Handler(void)
{
	TIMR_INTClr(TIMR0);
#if 0
	if (rate == 25) {
		rate = 50;
	}
	else {
		rate = 25;
	}
	TIMR0->OCMAT0 = rate;
#endif
}
#endif

void Sm15155eTimer1Ms(void) {
#if 0	
	if (smTimer) {
		smTimer--;
		if (smTimer == 0) {
			smTimer = 200;
			Sm15155eStart();
		}
	}
#endif
}

