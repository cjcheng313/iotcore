#include "SWM201.h"
#include "mix.h"
#include <math.h>

int  rgbresult[5] = {0,0,0,0,0};

double sRGB[3][3] = { {0.4360520,0.3850816,0.1430874}, 
											{0.2224916,0.7168861,0.0606215}, 
											{0.0139291,0.0970970,0.7141855} };

double bulbR[3] = {2.2622, 1.0000, 0.0026};
double bulbG[3] = {0.1988, 1.0000, 0.2091};
double bulbB[3] = {2.3426, 1.0000, 13.9585};
double bulbW[3] = {1.3050, 1.0000, 0.1526};
double bulbC[3] = {0.9724, 1.0000, 1.3588};

double maxR=4.268125;
double maxG=8.2026;
double maxB=1.843;
double maxW=7.243225;
double maxC=10.95095;

double kr = 5.90;
double kg = 2.77;
double kb = 12.95;
double kw = 3.41;
double kc = 2.26;

double RGB[3][3] =  {{0.4772, -0.0793,-0.0744},
                      {-0.4844,1.0957,0.0028}, 
                      {0.0072,-0.0164,0.0716}};
double RGW[3][3] =  {{-0.5044,2.1669,-9.8852},
                      {-1.3405,3.0547,-8.5535}, 
                      {1.8449,-4.2217,18.4387}};

double RGC[3][3] =  {{0.4541, -0.0264,-0.3055},
                      {-0.5356,1.2130,-0.5094}, 
                      {0.0815,-0.1866,0.8149}};

double RBW[3][3] =  {{1.0326,-1.3357,-0.0776},
                      {0.0112,-0.0256,0.0716}, 
                      {-1.0438,2.3612,0.0060}};

double RBC[3][3] =  {{0.6958,-0.5737,-0.0757},
                      {0.0749,-0.1696,0.0712}, 
                      {-0.7706,1.7433,0.0044}};

double RWC[3][3] =  {{1.0919,-1.4709,0.3011},
                      {-1.2277,2.7804,-1.1677}, 
                      {0.1358,-0.3095,0.8665}};

double GBW[3][3] =  {{-0.9005,1.1649,0.0677},
                      {0.0037,-0.0158,0.0722}, 
                      {0.8969,-0.1491,-0.1398}};

double GBC[3][3] =  {{-1.5419,1.2715,0.1677},
                      {-0.1407,0.0082,0.0947}, 
                      {1.6826,-0.2796,-0.2624}};

double BWC[3][3] =  {{0.2064,-0.2780,0.0569},
                      {2.1561,-1.7779,-0.2345}, 
                      {-2.3625,3.0559,0.1776}};

double GWC[3][3] =  {{-0.9169,1.2351,-0.2529},
                      {0.8740,-0.0508,-0.5881}, 
                      {0.0429,-0.1843,0.8409}};
											
double caculateRGB(int value){
	double result;
    double tem = value/255.00;
	if(value<=10){
	  result = tem/12.92;
	}else{
	  result = pow(((tem + 0.055)/1.055),2.4);
	}
    return result;
}


void matrixCal31(double a[3][3], double b[3], double result[3]){

	result[0] = a[0][0]*b[0]+a[0][1]*b[1]+a[0][2]*b[2];
	result[1] = a[1][0]*b[0]+a[1][1]*b[1]+a[1][2]*b[2];
	result[2] = a[2][0]*b[0]+a[2][1]*b[1]+a[2][2]*b[2];
}

int checkPostive(double a[3]){

	for(int i=0; i<3;i++){
        if(a[i]<0)
            return 0;
    }
    return 1;
}


void colormix(int r,int g, int b, int result[5]){
	
	double R,G,B;
	R=caculateRGB(r);
	G=caculateRGB(g);
	B=caculateRGB(b);
	
	double X,Y,Z;
	X = sRGB[0][0]*R+sRGB[0][1]*G+sRGB[0][2]*B;
	Y = sRGB[1][0]*R+sRGB[1][1]*G+sRGB[1][2]*B;
	Z = sRGB[2][0]*R+sRGB[2][1]*G+sRGB[2][2]*B;
	
	double x,y,z;
    double sum = X+Y+Z;
	x = X/sum;
	y = Y/sum;
	z = Z/sum;
	
	double X1,Y1,Z1;
	X1 = x/y;
	Y1 = 1;
	Z1 = z/y;
	
    double lightRatio[10][5];
     for (int i = 0; i < 10; i++ )
   {
      for (int j = 0; j < 5; j++ )
      {
          lightRatio[i][j]=0;
      }
   }
    double target[3] = {X1,Y1,Z1};
    double reRGB[3] = {0.00,0.00,0.00};
    double reRGW[3] = {0.00,0.00,0.00};
    double reRGC[3] = {0.00,0.00,0.00};
    double reRBW[3] = {0.00,0.00,0.00};
    double reRBC[3] = {0.00,0.00,0.00};

    double reRWC[3] = {0.00,0.00,0.00};

    double reGBW[3] = {0.00,0.00,0.00};
    double reGBC[3] = {0.00,0.00,0.00};
    double reBWC[3] = {0.00,0.00,0.00};
    double reGWC[3] = {0.00,0.00,0.00};

    matrixCal31(RGB,target,reRGB);
    int count = 0;
    if(checkPostive(reRGB)==1){
        lightRatio[0][0]=reRGB[0];
        lightRatio[0][1]=reRGB[1];
        lightRatio[0][2]=reRGB[2];
        count++;
    }
    matrixCal31(RGW,target,reRGW);
    if(checkPostive(reRGW)==1){
        lightRatio[1][0]=reRGW[0];
        lightRatio[1][1]=reRGW[1];
        lightRatio[1][3]=reRGW[2];
        count++;
    }
    matrixCal31(RGC,target,reRGC);
    if(checkPostive(reRGC)==1){
        lightRatio[2][0]=reRGC[0];
        lightRatio[2][1]=reRGC[1];
        lightRatio[2][4]=reRGC[2];
        count++;
    }
    matrixCal31(RBW,target,reRBW);
    if(checkPostive(reRBW)==1){
        lightRatio[3][0]=reRBW[0];
        lightRatio[3][2]=reRBW[1];
        lightRatio[3][3]=reRBW[2];
        count++;
    }
    matrixCal31(RBC,target,reRBC);
    if(checkPostive(reRBC)==1){
        lightRatio[4][0]=reRBC[0];
        lightRatio[4][2]=reRBC[1];
        lightRatio[4][4]=reRBC[2];
        count++;
    }
    matrixCal31(RWC,target,reRWC);
    if(checkPostive(reRWC)==1){
        lightRatio[5][0]=reRWC[0];
        lightRatio[5][3]=reRWC[1];
        lightRatio[5][4]=reRWC[2];
        count++;
    }
    matrixCal31(GBW,target,reGBW);
    if(checkPostive(reGBW)==1){
        lightRatio[6][1]=reGBW[0];
        lightRatio[6][2]=reGBW[1];
        lightRatio[6][3]=reGBW[2];
        count++;
    }
    matrixCal31(GBC,target,reGBC);
    if(checkPostive(reGBC)==1){
        lightRatio[7][1]=reGBC[0];
        lightRatio[7][2]=reGBC[1];
        lightRatio[7][4]=reGBC[2];
        count++;
    }
    matrixCal31(BWC,target,reBWC);
    if(checkPostive(reBWC)==1){
        lightRatio[8][2]=reBWC[0];
        lightRatio[8][3]=reBWC[1];
        lightRatio[8][4]=reBWC[2];
        count++;
    }
    matrixCal31(GWC,target,reGWC);
    if(checkPostive(reGWC)==1){
        lightRatio[9][1]=reGWC[0];
        lightRatio[9][3]=reGWC[1];
        lightRatio[9][4]=reGWC[2];
        count++;
    }

    double sumR = 0.00;
    for(int i=0;i<10;i++){
        sumR +=lightRatio[i][0];
    }

    double sumG = 0.00;
    for(int i=0;i<10;i++){
        sumG +=lightRatio[i][1];
    }

    double sumB = 0.00;
    for(int i=0;i<10;i++){
        sumB +=lightRatio[i][2];
    }

    double sumW = 0.00;
    for(int i=0;i<10;i++){
        sumW +=lightRatio[i][3];
    }

    double sumC = 0.00;
    for(int i=0;i<10;i++){
        sumC +=lightRatio[i][4];
    }

    double totalsum = sumR+sumG+sumB+sumC+sumW;

    double perR = sumR/count*7;
    double perG = sumG/count*7;
    double perB = sumB/count*7;
    double perW = sumW/count*7;
    double perC = sumC/count*7;

    double sumlight = r+g+b;

    double cr = perR*kr;
    double cg = perG*kg;
    double cb = perB*kb;
    double cw = perW*kw;
    double cc = perC*kc;

    

    result[0]=cr/30*255;
    result[1]=cg/32*255;
    result[2]=cb/32*255;
    result[3]=cw/40*255;
    result[4]=cc/40*255;
}


void colormixsimple(int r,int g, int b, int c[]){
    double vmax = r;
    if(vmax<g) vmax = g;
    if(vmax<b) vmax = b;
    double vmin = r;
    if(vmin>g) vmin = g;
    if(vmin<b) vmin = b;
    int w = vmin*1.1;
    double m = vmin/vmax;
    int rw = (1+m)*r-w;
    int gw = (1+m)*g-w;
    int bw = (1+m)*b-w;

    double temp = w/255.00 *(6500.00-2700.00) + 2700.00;
    double x = 0.00;
    x=(6500-temp)/(6500-2700);
    int white = w*x*100/255;
    int yellow = w*(1-x)*100/255;

    if(rw>0){
			c[0] = rw;
		}
    if(gw>0)
    c[1] = gw;
    if(bw>0)
    c[2] = bw;
    if(white>0)
    c[3] = yellow;
    if(yellow>0)
    c[4] = white;
}