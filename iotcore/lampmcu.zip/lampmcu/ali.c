#include "string.h"
#include "SWM201.h"
#include "makedef.h"
#include "led.h"
#include "lamp.h"
#include "uart.h"
#include "ali.h"

static 	uint8_t		aliState;
static 	uint32_t	aliTimer;
static 	uint32_t	aliUartTimer;

const char AT[] = "AT\n\r";
const char AT_RST[] = "AT+RST\n\r";
const char AT_GMR[] = "AT+GMR\n\r";
const char AT_MAC[] = "AT+CIPSTAMAC_DEF?\n\r";
const char AT_CONNECTEDCHECK[] = "AT+CONNECTEDCHECK?\n\r";
const char AT_RECVJSON[] = "AT+RECVJSON\n\r";
const char AT_GETCONFIG[] = "AT+LINKKEYCONFIG?\n\r";
const char AT_RESTORE[] = "AT+RESTORE\n\r";
// old
//const char AT_LINKKEYCONFIG[] = "AT+LINKKEYCONFIG=\"a1KN3RmnLWb\",\"b4e8420fc82e\",\"4a1cbfcd8421404ea0aac2054f2a9ba2\",\"HkpNs4G5uaajiXdK\",\"9215242\"\n\r";
// new
const char AT_LINKKEYCONFIG[] = "AT+LINKKEYCONFIG=\"a1KN3RmnLWb\",\"b4e8420fcca2\",\"f6e179143c116648c14ec27f0ae735fe\",\"HkpNs4G5uaajiXdK\",\"9215242\"\n\r";
const char AT_ALIBTSMARTCONFIG[] = "AT+ALIBTSMARTCONFIG\n\r";


char	waitStr[128];

static  uint8_t        UartReadBuffer[256];
static  uint16_t        UartReadLength;

struct JSON_TYPE{
	char key[32];
	char val_str[32];
	uint32_t val_uint;
	
};

struct JSON_TYPE 	jsonBuff[10];
uint8_t				jsonSize;

enum {
	STATE_IDLE = 0,
	STATE_INIT = 10,
	STATE_MATCH = 20,
	STATE_WORK = 30,
};

uint8_t		matchFlag;
uint8_t		configFlag;


CONTROL_DATA 	ControlData;
SCENE_DATA 		SceneData;
PALETTE_DATA	PaletteData;

void AliInit(void) {
	aliState = 0;
	aliTimer = 1000 * 5;
	aliUartTimer = 0;
	
	matchFlag = 0;
	configFlag = 0;
	
	UartReadBuffer[0] = 0;
	UartReadLength = 0;
	
}


void AliTimer1Ms(void) {
	if (aliTimer)	aliTimer--;
	if (aliUartTimer)	aliUartTimer--;

}

const char	hex2asc[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', };
uint8_t toupper(uint8_t c) {
	if (c >= 'a' && c <= 'z')
		return c - 0x20;
	return c;	
}

uint32_t str2dec(char *src, uint8_t len)
{
    uint32_t		res;
    uint8_t		i;

    res = 0;
    for (i = 0; i < len; i++) {
		res *= 10;
		res += src[i] - '0';
    }

    return res;
}

uint32_t str2hex(char *src, uint8_t len)
{
    uint32_t	res;
    uint8_t		i, j;
	
    if (len > 8)
		len = 8;

    res = 0;
    for (i = 0; i < len; i++) {
		res <<= 4;
		for (j = 0; j < sizeof(hex2asc); j++) {
			if (hex2asc[j] == toupper(src[i])) {	// toupper(src[i])
				res |= j;
				break;
			}
		}
    }

    return res;
}

void split(char *src,const char *separator,char **dest, uint8_t *num) {
     char *pNext;
     int count = 0;
     if (src == NULL || strlen(src) == 0)
        return;
     if (separator == NULL || strlen(separator) == 0)
        return;    
     pNext = strtok(src,separator);
     while(pNext != NULL) {
          *dest++ = pNext;
          ++count;
         pNext = strtok(NULL,separator);  
    }  
    *num = count;
}     

void AliPickEqStr(char source[], uint8_t len, char k[], char dest[]) {
	char *		StrCurr;
    char *		StrNext;
    uint8_t		LenCurr;
	
	dest[0] = 0;
	
	k[0] = 0;
	if ((StrCurr = strstr(source, k)) == 0) return;
	LenCurr = strlen(k);	
	StrCurr = StrCurr + LenCurr;
	if (StrCurr[0] != '=') return;
	StrCurr = StrCurr + 1;
	if ((StrNext = strchr(StrCurr, ',')) == 0)	{
		if ((StrNext = strchr(StrCurr, '}')) == 0) return;
	}
	if (StrNext - source >= len) return;
	LenCurr = StrNext - StrCurr;
	if (LenCurr >= 150) return;
	
	strncpy(dest, StrCurr, LenCurr);
	dest[LenCurr] = 0;
	
}	
//{currentTime=2021-11-14, scheduleList=[{times=390|690|1020|1260, color=#f8d4bc|#ff850d|#e0e5fb, weekDays=0123456, actions=1|1|1|1|1|1|1|1}]}
void AliGetControlData(char *buff, uint8_t len) {
	//ControlData
	char	unit[32];
	uint8_t	ind = 0;
	char 	*revbuf[10] = {0};
	uint8_t	num = 0;
	uint8_t	i;

	memset(ControlData.times, 0, 10);
	memset(ControlData.color, 0, 10);
	memset(ControlData.actions, 0, 7);
	memset(ControlData.weekDays, 0, 7);
	
	AliPickEqStr(buff, len, "currentTime", unit);
	if (unit[0]) {
		ControlData.currentTime = 0;		
	}
	
	AliPickEqStr(buff, len, "times", unit);
	if (unit[0]) {
		split(unit,"|",revbuf,&num);
		for(i = 0;i < num; i++) {
			ControlData.times[i] = str2dec(revbuf[i], strlen(revbuf[i]));
		}		
	}

	AliPickEqStr(buff, len, "color", unit);
	if (unit[0]) {
		split(unit,"|",revbuf,&num);
		for(i = 0;i < num; i++) {
			ControlData.color[i] = str2hex(revbuf[i] + 1, strlen(revbuf[i]) -  1);
		}		
	}
	
	
	AliPickEqStr(buff, len, "actions", unit);
	if (unit[0]) {
		split(unit,"|",revbuf,&num);
		for(i = 0;i < num; i++) {
			ControlData.actions[i] = str2dec(revbuf[i], strlen(revbuf[i]));
		}	
	}
	
	AliPickEqStr(buff, len, "weekDays", unit);
	if (unit[0]) {
		for(i = 0;i < strlen(unit); i++) {
			ControlData.weekDays[i] = unit[i] - '0';
		}
	}
}

enum {
	COMM_SWITCH = 0x10,
	COMM_CAIGUANG = 0,
	COMM_BAIGUANG = 1,
	COMM_CHANGJING_JT = 2,
	COMM_CHANGJING_DT = 3,
	COMM_YINYUE = 4,
	COMM_JIELV = 5,
	COMM_SEBAN = 6,
	COMM_OTHER = 0xFF
};

const char key_swtichLed[] = "switchLed";
const char key_swtichMode[] = "switchMode";
const char key_colourData[] = "colourData";
const char key_tempValue[] = "tempValue";
const char key_brightValue[] = "brightValue";
const char key_musicData[] = "musicData";



uint8_t	AliGetCommType(void) {
	uint8_t	type = COMM_OTHER;
	uint8_t	i;
	
	if (jsonSize > 0) {
		for (i = 0; i < jsonSize; i++) {
			if (strncmp(jsonBuff[i].key, key_swtichLed, strlen(key_swtichLed)) == 0) {
				type = COMM_SWITCH;
			}
			else if (strncmp(jsonBuff[i].key, key_swtichMode, strlen(key_swtichMode)) == 0) {
				switch (jsonBuff[i].val_uint) {
					case 0: type = COMM_CAIGUANG;		break;
					case 1: type = COMM_BAIGUANG;		break;
					case 2: type = COMM_CHANGJING_JT;		break;
					case 3: type = COMM_CHANGJING_DT;		break;
					case 4: type = COMM_YINYUE;		break;
					case 5: type = COMM_JIELV;		break;
					case 6: type = COMM_SEBAN;		break;
				}
			}
		}		
	}
	return type;
}

uint32_t AliGetCommValue(char *key) {
	uint8_t	i;
	
	
	if (jsonSize > 0) {
		for (i = 0; i < jsonSize; i++) {
			if (strncmp(jsonBuff[i].key, key, strlen(key)) == 0) {
				if (strncmp(jsonBuff[i].key, key_swtichLed, strlen(key_swtichLed)) == 0 ||
					strncmp(jsonBuff[i].key, key_swtichMode, strlen(key_swtichMode)) == 0 ||
					strncmp(jsonBuff[i].key, key_tempValue, strlen(key_tempValue)) == 0 ||
					strncmp(jsonBuff[i].key, key_brightValue, strlen(key_brightValue)) == 0 ||
					strncmp(jsonBuff[i].key, key_colourData, strlen(key_colourData)) == 0) {
					return jsonBuff[i].val_uint;
				}
				else if (strncmp(jsonBuff[i].key, key_musicData, strlen(key_musicData)) == 0) {
					return str2dec(jsonBuff[i].val_str, strlen(jsonBuff[i].val_str));
				}					
			}
		}		
	}
	
	return 0xFFFFFFFF;
}

//{showTimes=0, intervalTimes=100, colorList=ff0000|fff000|2400ff|f65e86|05b6f8|4af805|f83e05|d305f8|f85b05|1cf805, status=3, timeRange=100}
void AliGetSceneData(char *buff, uint16_t slen) {
	//ControlData
	char		unit[100];
	char 		*revbuf[10] = {0};
	uint8_t		num = 0;
	uint8_t		i;
	uint16_t	interval = 100;

	SceneData.showTimes = 0;
	SceneData.status = 3;
	SceneData.total = 0;
	for (i = 0; i < 10; i++) {
		SceneData.intervalTimes[i] = 100;
		SceneData.color[i] = 0;
	}

	AliPickEqStr(buff, slen, "showTimes", unit);
	if (unit[0]) {
		SceneData.showTimes = str2dec(unit, strlen(unit));
	}
	
	AliPickEqStr(buff, slen, "intervalTimes", unit);
	if (unit[0]) {
		split(unit,"|",revbuf,&num);
		if (num > 10) num = 10;
		if (num > SceneData.total) SceneData.total = num;
		for(i = 0; i < num; i++) {
			interval = str2dec(revbuf[i], strlen(revbuf[i]));
			SceneData.intervalTimes[i] = interval;
		}
		while (num < 10) {
			SceneData.intervalTimes[num++] = interval;
		}
	}

	AliPickEqStr(buff, slen, "colorList", unit);
	if (unit[0]) {
		split(unit,"|",revbuf,&num);
		if (num > 10) num = 10;
		if (num > SceneData.total) SceneData.total = num;
		for(i = 0;i < num; i++) {
			SceneData.color[i] = str2hex(revbuf[i], strlen(revbuf[i]));
		}		
	}

	AliPickEqStr(buff, slen, "status", unit);
	if (unit[0]) {
		SceneData.status = str2dec(unit, strlen(unit));
		if (SceneData.status == 2) {	// stop=2
			SceneData.total = 0;
		}
	}
}

//{rgb=ff00a5|ff00a5|ff00a5|ff0054|ffdfc2|ff0054|ff00a5|ffdfc2|ff00a5|ff00a5|ff0054, id=0|1|3|4|5|6|8|9|10|11|14}
void AliGetColorPaletteData(char *buff, uint16_t slen) {
	//ControlData
	char		unit[150];
	char 		*revbuf[15] = {0};
	uint8_t		num = 0;
	uint8_t		i;


	PaletteData.total = 0;
	for (i = 0; i < 10; i++) {
		PaletteData.id[i] = 0xFF;
		PaletteData.rgb[i] = 0;
	}


	AliPickEqStr(buff, slen, "rgb", unit);
	if (unit[0]) {
		split(unit,"|",revbuf,&num);
		if (num > 15) num = 15;
		if (num > PaletteData.total) PaletteData.total = num;
		for(i = 0; i < num; i++) {
			PaletteData.rgb[i] = str2hex(revbuf[i], strlen(revbuf[i]));
		}
	}
	
	
	AliPickEqStr(buff, slen, "id", unit);
	if (unit[0]) {
		split(unit,"|",revbuf,&num);
		if (num > 15) num = 15;
		for(i = 0;i < num; i++) {
			PaletteData.id[i] = str2dec(revbuf[i], strlen(revbuf[i]));
		}		
	}
}


//KaiGuan :		{"switchLed":0}
//CaiGuang  : 	{"brightValue":100,"colourData":"99ffff","switchMode":0}
//BaiGuang :	{"tempValue":4100,"brightValue":100,"switchMode":1}
//ChangJing(jt):{"colourData":"33ccff","tempValue":2700,"brightValue":30,"switchMode":2}
//ChangJing(dt):{"sceneData":"{showTimes=0, intervalTimes=100, colorList=ff0000|fff000|2400ff|f65e86|05b6f8|4af805|f83e05|d305f8|f85b05|1cf805, status=3, timeRange=100}","switchMode":3}
//TiaoSeBan :	{"colorPaletteData":"{rgb=ff00a5|ff00a5|ff00a5|ff0054|ffdfc2|ff0054|ff00a5|ffdfc2|ff00a5|ff00a5|ff0054, id=0|1|3|4|5|6|8|9|10|11|14}","switchMode":6}


//ShengWuJieLv	{"controlData":"{currentTime=2021-11-14, scheduleList=[{times=390|690|1020|1260, color=#f8d4bc|#ff850d|#e0e5fb, weekDays=0123456, actions=1|1|1|1|1|1|1|1}]}","switchMode":5}
				// actions   1= turn on , 2= turn off
//DingShiJieLv	{"controlData":"{currentTime=2021-11-14, scheduleList=[{times=1223|1223|1223|1223|1223, weekDays=12345, actions=1|1|1|1|1}]}","switchMode":5}
				// actions   1= turn on , 2= turn off

void AliProJson(char *buff, uint8_t len) {
	
	char *		StrCurr;
    char *		StrNext;
    uint8_t		LenCurr;
	uint8_t		commType;
	uint16_t	commValue;
	
	jsonSize = 0;
	StrCurr = buff;
	while (1) {
		if ((StrNext = strchr(StrCurr, '"')) == 0)	break;
		StrCurr = StrNext + 1;
		if ((StrNext = strchr(StrCurr, '"')) == 0)	break;
		LenCurr = StrNext - StrCurr;
		memcpy(jsonBuff[jsonSize].key, StrCurr, LenCurr);
		
#if 0		
		if (strncmp(jsonBuff[jsonSize].key, "controlData", LenCurr) == 0) {
			StrCurr = StrNext + 1;
			if (StrCurr[0] != ':') break;
			StrCurr = StrCurr + 1;
			if (strncmp(StrCurr, "\"{", 2) != 0) break;
			StrCurr = StrCurr + 2;
			if ((StrNext = strstr(StrCurr, "}\"")) == 0) break;
			StrNext = StrNext + 2;
			LenCurr = StrNext - StrCurr;
			
			AliGetControlData(StrCurr, LenCurr);
			StrCurr = StrNext + 1;
		}
#endif
		if (strncmp(jsonBuff[jsonSize].key, "colorPaletteData", LenCurr) == 0) {
			StrCurr = StrNext + 1;
			if (StrCurr[0] != ':') break;
			StrCurr = StrCurr + 1;
			if (strncmp(StrCurr, "\"{", 2) != 0) break;
			StrCurr = StrCurr + 2;
			if ((StrNext = strstr(StrCurr, "}\"")) == 0) break;
			StrNext = StrNext + 2;
			LenCurr = StrNext - StrCurr;
			
			StrCurr[LenCurr] = 0;
			AliGetColorPaletteData(StrCurr, LenCurr);
			strcpy(jsonBuff[0].key, "switchMode");
			jsonBuff[0].val_uint = 6;
			jsonSize = 1;
		}
		else if (strncmp(jsonBuff[jsonSize].key, "sceneData", LenCurr) == 0) {
			StrCurr = StrNext + 1;
			if (StrCurr[0] != ':') break;
			StrCurr = StrCurr + 1;
			if (strncmp(StrCurr, "\"{", 2) != 0) break;
			StrCurr = StrCurr + 2;
			if ((StrNext = strstr(StrCurr, "}\"")) == 0) break;
			StrNext = StrNext + 2;
			LenCurr = StrNext - StrCurr;
			
			StrCurr[LenCurr] = 0;
			AliGetSceneData(StrCurr, LenCurr);
			strcpy(jsonBuff[0].key, "switchMode");
			jsonBuff[0].val_uint = 3;
			jsonSize = 1;
			break;			
		}			
		else {
			StrCurr = StrNext + 1;
			if (StrCurr[0] != ':') break;
			StrCurr = StrCurr + 1;
			if ((StrNext = strchr(StrCurr, ',')) == 0)	{
				if ((StrNext = strchr(StrCurr, '}')) == 0) break;
			}		
			LenCurr = StrNext - StrCurr;
			if (StrCurr[0] == '"' && StrCurr[LenCurr - 1] == '"') {
				if (strncmp(jsonBuff[jsonSize].key, "colourData", 10) == 0) {
					jsonBuff[jsonSize].val_uint = str2hex(StrCurr + 1, LenCurr - 2);				
				}
				else {
					memcpy(jsonBuff[jsonSize].val_str, StrCurr + 1, LenCurr - 2);
				}
			}
			else {
				jsonBuff[jsonSize].val_uint = str2dec(StrCurr, LenCurr);
			}
			StrCurr = StrNext + 1;	
		}
		
		jsonSize++;
		if (jsonSize >= 10) break;
	}
	
	if (jsonSize > 0) {
		commType = AliGetCommType();
		switch (commType) {
			case COMM_SWITCH:
				lampSwitchValue = AliGetCommValue((char *)key_swtichLed);
				lampUpdateFlag = 1;
				lampDynamicFlag	= 0;
				lampMusicFlag = 0;
				break;
			case COMM_CAIGUANG:
				lampWhiteValue = 0;
				lampYellowValue = 0;
				lampColorValue = AliGetCommValue((char *)key_colourData);
				lampUpdateFlag = 1;
				lampDynamicFlag	= 0;
				lampMusicFlag = 0;
				break;
			case COMM_BAIGUANG:
				lampColorValue = 0x000000;
			
				lampBrightValue = AliGetCommValue((char *)key_brightValue);
				if (lampBrightValue > 100) lampBrightValue = 100;
			
				commValue = AliGetCommValue((char *)key_tempValue);
				if (commValue < 2700) commValue = 2700;
				else if (commValue > 6500) commValue = 6500;
			
				lampWhiteValue = (commValue - 2700) * 100 / (6500-2700);
				lampYellowValue = 100 - lampWhiteValue;
				lampUpdateFlag = 1;			
				lampDynamicFlag	= 0;
				lampMusicFlag = 0;
				break;
			case COMM_CHANGJING_JT:
				lampColorValue = AliGetCommValue((char *)key_colourData);
				lampBrightValue = AliGetCommValue((char *)key_brightValue);
				if (lampBrightValue > 100) lampBrightValue = 100;
			
				commValue = AliGetCommValue((char *)key_tempValue);
				if (commValue < 2700) commValue = 2700;
				else if (commValue > 6500) commValue = 6500;
			
				lampWhiteValue = (commValue - 2700) * 100 / (6500-2700);
				lampYellowValue = 100 - lampWhiteValue;
				lampUpdateFlag = 1;
				lampDynamicFlag	= 0;
				lampMusicFlag = 0;
				break;
			case COMM_CHANGJING_DT:
				if (SceneData.total >= 2) {
					lampDynamicFlag = 1;
					lampMusicFlag = 0;
				}
				break;
			case COMM_YINYUE:
				lampMusicData = AliGetCommValue((char *)key_musicData);
				lampMusicFlag = 1;
				lampDynamicFlag = 0;			
				break;
			case COMM_JIELV:
				break;
			case COMM_SEBAN:
				if (PaletteData.total) {
					lampPaletteFlag = 1;
					lampMusicFlag = 0;
					lampDynamicFlag = 0;
				}
				break;
			
		}		
	}
}

void AliProcJsonData(void)
{
    char        	*TempBuff;
    uint8_t        	Ind;
	
	if (aliUartTimer) return;

    UartReadLength = uart1Read(UartReadBuffer, 256);
    if (UartReadLength) {	
		if ((TempBuff = strchr((char *)UartReadBuffer, '{')) != 0) {
			Ind = TempBuff - (char *)UartReadBuffer;
			memmove(UartReadBuffer, UartReadBuffer + Ind, UartReadLength - Ind);
            UartReadLength -= Ind;
			UartReadBuffer[UartReadLength] = 0;

			if (UartReadBuffer[0] == '{' && UartReadBuffer[UartReadLength - 5] == 0x7d) {	// '}'
				AliProJson((char *)UartReadBuffer, UartReadLength);				
			}	
		}
    }
}

uint8_t AliWaitUartData()
{
    uint8_t        	TempBuff[180];
    uint8_t        	Len;
	uint8_t			aa = strlen(waitStr);

	if (aliUartTimer) return 0;
	
    Len = uart1Read(TempBuff, 180);
    if (Len) {
        if (Len + UartReadLength >= 256) {
            UartReadLength = 0;
        }
        memcpy(UartReadBuffer + UartReadLength, TempBuff, Len);
        UartReadLength += Len;
    }

    if (UartReadLength >= 2) {
        if (UartReadBuffer[0] == waitStr[0]) {	// '{'
			if (strstr((char *)UartReadBuffer, waitStr)) {
				UartReadLength = 0;
				return 1;	
			}				
        }
        else {
            memmove(UartReadBuffer, UartReadBuffer + 1, UartReadLength - 1);
            UartReadLength -= 1;
        }
    }
	
	return 0;
}

void getMac(void) {
	configFlag = 1;
	aliState = 0;
	aliTimer = 1000;
	uart1Send((uint8_t*)AT_MAC, sizeof(AT_MAC)/sizeof(char) - 1);
}

void getConfig(void) {
	configFlag = 1;
	aliState = 0;
	aliTimer = 1000;
	uart1Send((uint8_t*)AT_GETCONFIG, sizeof(AT_GETCONFIG)/sizeof(char) - 1);
}

void sendConfig(void) {
	configFlag = 1;
	aliState = 0;
	aliTimer = 1000;
	
	uart1Send((uint8_t*)AT_LINKKEYCONFIG, sizeof(AT_LINKKEYCONFIG)/sizeof(char) - 1);	
}

void sendRst(void) {
	configFlag = 1;
	aliState = 0;
	aliTimer = 1000;
	uart1Send((uint8_t*)AT_RST, sizeof(AT_RST)/sizeof(char) - 1);	
}

void sendFactory(void) {
	configFlag = 1;
	aliState = 0;
	aliTimer = 1000;
	uart1Send((uint8_t*)AT_RESTORE, sizeof(AT_RESTORE)/sizeof(char) - 1);
}

void pollingAli(void) {	
	if (aliState != STATE_IDLE && matchFlag) {
		aliState = STATE_IDLE;
	}
	
	switch (aliState) {
	case STATE_IDLE:		
		if (configFlag) {
			if (aliTimer) break;
			AliWaitUartData();
			configFlag = 0;
			break;
		}	
		else if (matchFlag) {
			lampStartShine(0xFF0000);
			matchFlag = 0;
			aliState = STATE_MATCH;
			aliTimer = 10;
			break;
		}
		else {
			lampStartShine(0x00FF00);
			aliState = STATE_INIT;
		}
		break;
	
	
	case STATE_INIT:
		UartReadLength = 0;
		strcpy(waitStr, "OK");
		uart1Send((uint8_t*)AT, sizeof(AT)/sizeof(char) - 1);
		aliState++;
		aliTimer = 2000;
		aliUartTimer = 1000;
		break;
	case STATE_INIT + 1:
		if (AliWaitUartData()) {
			aliState++;
		}
		else if (aliTimer == 0) {
			aliState--;			
		}
		break;
	case STATE_INIT + 2:
		UartReadLength = 0;
		strcpy(waitStr, "CONNECTEDCHECK:1");
		uart1Send((uint8_t*)AT_CONNECTEDCHECK, sizeof(AT_CONNECTEDCHECK)/sizeof(char) - 1);
		aliState++;
		aliTimer = 2000;
		aliUartTimer = 1000;
		break;
	case STATE_INIT + 3:
		if (AliWaitUartData()) {
			lampStopShine();
			aliState = STATE_WORK;
		}
		else if (aliTimer == 0) {
			aliState = 0;			
		}
		break;
		
	case STATE_MATCH:
		UartReadLength = 0;
		strcpy(waitStr, "OK");
		uart1Send((uint8_t*)AT_RESTORE, sizeof(AT_RESTORE)/sizeof(char) - 1);
		aliState++;
		aliTimer = 1000 * 5;
		aliUartTimer = 1000;
		break;
	case STATE_MATCH + 1:
		if (AliWaitUartData()) {
			aliState++;
		}
		else if (aliTimer == 0) {
			aliState--;			
		}
		break;
	case STATE_MATCH + 2:
		UartReadLength = 0;
		strcpy(waitStr, "OK");
		uart1Send((uint8_t*)AT_LINKKEYCONFIG, sizeof(AT_LINKKEYCONFIG)/sizeof(char) - 1);
		aliState++;
		aliTimer = 1000 * 5;
		aliUartTimer = 2000;
		break;
	case STATE_MATCH + 3:
		if (AliWaitUartData()) {
			aliState++;
		}
		else if (aliTimer == 0) {
			aliState--;			
		}
		break;		
	case STATE_MATCH + 4:
		UartReadLength = 0;
		strcpy(waitStr, "CLOUD CONNECTED");
		uart1Send((uint8_t*)AT_ALIBTSMARTCONFIG, sizeof(AT_ALIBTSMARTCONFIG)/sizeof(char) - 1);
		aliState++;
		aliTimer = 1000 * 60 * 2;
		aliUartTimer = 1000;
		break;
	case STATE_MATCH + 5:
		if (AliWaitUartData()) {
			aliState = 0;
		}
		else if (aliTimer == 0) {
			aliState--;			
		}
		break;
		
		

	case STATE_WORK:
		AliProcJsonData();
		if (aliTimer == 0) {
			uart1Send((uint8_t*)AT_RECVJSON, sizeof(AT_RECVJSON)/sizeof(char) - 1);
			aliUartTimer = 50;
			aliTimer = 500;			
		}
		
		break;

	default:
		aliState = 0;
		break;
	}
}


