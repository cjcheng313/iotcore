#ifndef	_LAMP_H
#define	_LAMP_H

typedef struct {
	uint8_t	r;
	uint8_t	g;
	uint8_t	b;
	uint8_t	w;
	uint8_t	y;
}COLOR_5;

extern 	uint8_t		lampMusicFlag;
extern	uint8_t		lampMusicData;

extern	uint8_t		lampUpdateFlag;
extern	uint8_t		lampBrightValue;
extern	uint16_t	lampYellowValue;
extern	uint16_t  	lampWhiteValue;
extern	uint32_t	lampColorValue;
extern	uint8_t		lampSwitchValue;

extern	uint8_t		lampDynamicFlag;
extern	uint8_t		lampPaletteFlag;


extern	void 	LampInit(void);
extern	void	LampStart(void);

extern 	void 	LampInit(void);
extern 	void 	LampTimer1Ms(void);
extern 	void 	pollingLamp(void);

extern	void 	lampStartShine(uint32_t color);
extern	void 	lampStopShine(void);

void lampColorPlus(void);
void lampColorMinus(void);
void lampBrightPlus(void);
void lampBrightMinus(void);


#endif
