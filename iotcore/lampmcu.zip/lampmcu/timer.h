#ifndef	_TIMER_H
#define	_TIMER_H


extern	void TimerInit(void);


#endif
