#include "SWM201.h"
#include "makedef.h"
#include "mbi6023.h"

#ifdef	SUPPORT_LAMP_MBI6023
#define	CKI_GPIO		GPIOB		// output, no pulldown, no pullup, no opendrain
#define	CKI_PIN			PIN4
#define	SDI_GPIO		GPIOB		// output, no pulldown, no pullup, no opendrain
#define	SDI_PIN			PIN5

MBI6023_Chip	OsdColorData;
uint16_t	OsdColorBuffer[IC_MAX*12];

void MBI6023Init(void) {
	GPIO_Init(CKI_GPIO, CKI_PIN, 1, 0, 0, 0);			// output, no pulldown, no pullup, no opendrain
	GPIO_ClrBit(CKI_GPIO, CKI_PIN);
	GPIO_Init(SDI_GPIO, SDI_PIN, 1, 0, 0, 0);			// output, no pulldown, no pullup, no opendrain
	GPIO_ClrBit(SDI_GPIO, SDI_PIN);
}

void delay(uint16_t	n) {
	while (n--) {
		__nop();
	}
}
void MBI6023SendUint16(uint16_t data) {
	uint16_t	sd = data;
	uint8_t		i;
	
	for (i = 0; i < 16; i++) {
		GPIO_SetBit(CKI_GPIO, CKI_PIN);
		delay(2);
		if (sd & 0x8000)
			GPIO_SetBit(SDI_GPIO, SDI_PIN);
		else
			GPIO_ClrBit(SDI_GPIO, SDI_PIN);
		delay(2);
		GPIO_ClrBit(CKI_GPIO, CKI_PIN);
		delay(20);
		sd <<= 1;
	}
}

uint16_t check_parity(uint16_t data)
{
	uint8_t	i = 0;
	uint8_t	r = 0;
	
	for (i = 0; i < 16; i++) {
		if (data & 0x8000)
			r++;
		data <<= 1;
	}
	return (r & 0x01);
}

void Delay_ms(uint16_t ms)
{
	uint16_t i;
	for(i=0;i<ms*1000;i++);		
}

static void MBI6023_Send_Header(MBI6023_Chip * pMBI_Chip)
{
	uint16_t H,P,A,L;
	uint16_t driver_num = pMBI_Chip->Driver_num;
	uint16_t * MBI6023_Header = pMBI_Chip->MBI6023_Header;
	MBI6023_Grey Grey_Level = pMBI_Chip->Grey_Level;
	
    //uint16_t MBI6023_Header;
	
	if (MBI6023_Grey_16bit == Grey_Level) {//calculate H,P,A,L according Grey grade
		H = 0x3f;
		A = 0x00;
		L = driver_num-1;
		P = check_parity(L)|(check_parity(A)<<1)||(check_parity(H)<<2);
		P = P | (check_parity(P)<<3);
	} 
	else {
		H = 0x2b;
		A = 0x00;
		L = driver_num-1;
		P = check_parity(L)|(check_parity(A)<<1)||(check_parity(H)<<2);
		P = P | (check_parity(P)<<3);
	}


	MBI6023_Header[0]=MBI6023_Header[1]=MBI6023_Header[2]=0;

	if(MBI6023_Grey_16bit == Grey_Level) { //Generate Package Head according Grey grade
		MBI6023_Header[2] = (H<<10) | A;
		MBI6023_Header[1] = (H<<10) | L;
		MBI6023_Header[0] = (P<<12) | L;
	}
	else {
		MBI6023_Header[2] = (H<<4) | P; 
		MBI6023_Header[1] = A;
		MBI6023_Header[0] = L;
	}

	MBI6023SendUint16(MBI6023_Header[2]);
	MBI6023SendUint16(MBI6023_Header[1]);
	MBI6023SendUint16(MBI6023_Header[0]);
}


static void MBI6023_Send_Color(MBI6023_Chip * pMBI_Chip)
{
	uint16_t i;
	uint16_t index = pMBI_Chip->Driver_num*12;

	for(i=0;i<index;i++)
		MBI6023SendUint16(OsdColorBuffer[index-i-1]);
		
}
void MBI6023_Senddata(uint8_t num)
{
	GPIO_ClrBit(SDI_GPIO, SDI_PIN);
	GPIO_ClrBit(CKI_GPIO, CKI_PIN);
	Delay_ms(10);
	
	OsdColorData.Driver_num = num;
	OsdColorData.Grey_Level = MBI6023_Grey_16bit;	
	MBI6023_Send_Header(&OsdColorData);
	MBI6023_Send_Color(&OsdColorData);
}
#endif


#if 0
uint16_t	data_b[36];
uint8_t		ind = 0;
void testMbi6023(void) {
	uint8_t i;
	
	uint16_t	aa, bb, cc;
	MBI6023_Chip 	send_data;
	send_data.Driver_num = 3;
	
	aa = check_parity(0x3f);
	bb = check_parity(0x00);
	cc = check_parity(0x02);
	
						//w		g		r		b		w				w		g		r		b		w
	uint16_t r[12] = {0x0000, 0x0000, 0xFFFF, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0xffff, 0x0000, 0x0000, 0x0000};
	uint16_t g[12] = {0x0000, 0xffff, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0xffff, 0x0000, 0x0000, 0x0000, 0x0000};	
	uint16_t b[12] = {0x0000, 0x0000, 0x0000, 0xffff, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0xffff, 0x0000, 0x0000};
	uint16_t w[12] = {0xffff, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0xffff, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000};
	uint16_t z[12] = {0x0000, 0x0000, 0x0000, 0x0000, 0xffff, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0xffff, 0x0000};
	
	

	if (ind == 0) {
		ind++;
		for (i = 0; i < 36; i++)
			data_b[i] = r[i % 12];
	}
	else if (ind == 1) {
		ind++;
		for (i = 0; i < 36; i++)
			data_b[i] = g[i % 12];
		
	}
	else if (ind == 2) {
		ind++;
		for (i = 0; i < 36; i++)
			data_b[i] = b[i % 12];
		
	}
	else if (ind == 3) {
		ind++;
		for (i = 0; i < 36; i++)
			data_b[i] = w[i % 12];
		
	}
	else if (ind == 4) {
		ind=0;
		for (i = 0; i < 36; i++)
			data_b[i] = z[i % 12];
		
	}

	MBI6023SendColor(3, data_b);
}
#endif

