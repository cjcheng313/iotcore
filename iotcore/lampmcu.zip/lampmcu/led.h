#ifndef	_LED_H
#define	_LED_H

extern	void 	LedInit(void);
extern	void 	LedWork(uint8_t t);
extern	void 	LedTimer1Ms(void);
extern	void 	PollingLed(void);

#endif
