#ifndef	_COLOR5_H
#define	_COLOR5_H

extern uint16_t	OsdColorBuffer[5];

extern	void Color5Init(void);
extern	void Color5Irq(void);

#endif
