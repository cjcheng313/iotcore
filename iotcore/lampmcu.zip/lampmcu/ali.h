#ifndef __ALI_H__
#define __ALI_H__


typedef struct {
	uint16_t	currentTime;
	uint16_t	times[10];
	uint8_t		timesLen;
	uint32_t	color[10];
	uint8_t		weekDays[7];
	uint8_t		actions[7];	
} CONTROL_DATA;

typedef struct {
	uint16_t	showTimes;	// how many times
	uint16_t	intervalTimes[10];
	uint32_t	color[10];
	uint8_t		status;
	uint8_t		total;
} SCENE_DATA;

typedef struct {
	uint32_t	rgb[15];
	uint8_t		id[15];
	uint8_t		total;
} PALETTE_DATA;

extern	CONTROL_DATA 	ControlData;
extern 	SCENE_DATA 		SceneData;
extern	PALETTE_DATA	PaletteData;

extern uint8_t	matchFlag;

extern 	void 	AliInit(void);
extern 	void 	AliTimer1Ms(void);
extern 	void 	pollingAli(void);


#endif
