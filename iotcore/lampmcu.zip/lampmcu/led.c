#include "SWM201.h"


static 	uint32_t	ledTimer;
static	uint8_t		ledState;

static	uint8_t		ledWorkFlag;
static	uint8_t		ledWorkMode;
	
#define	LED_GPIO		GPIOM		// output, no pulldown, no pullup, no opendrain
#define	LED_PIN			PIN8

void LedInit(void) {
	GPIO_Init(LED_GPIO, LED_PIN, 1, 0, 0, 0);			// output, no pulldown, no pullup, no opendrain
	GPIO_ClrBit(LED_GPIO, LED_PIN);
	
	ledTimer = 0;
	ledState = 0;
	
	ledWorkFlag = 0;
	ledWorkMode = 0;
}

void LedWork(uint8_t t) {
	ledWorkMode = t;
	ledWorkFlag = 1;
}

void LedTimer1Ms(void) {
	if (ledTimer) ledTimer--;	
}

void PollingLed(void) {
	if (ledWorkFlag) {
		if (ledTimer == 0) {
			GPIO_SetBit(LED_GPIO, LED_PIN);
			ledState = 1;

			ledWorkFlag = 0;
			ledTimer = 1000;
		}
	}
	else {
		if (ledTimer == 0) {
			ledTimer = 500;

			if (ledState) {
				ledState = 0;
				GPIO_ClrBit(LED_GPIO, LED_PIN);
			}
			else {
				ledState = 1;
				GPIO_SetBit(LED_GPIO, LED_PIN);
			}
		}
	}
}
