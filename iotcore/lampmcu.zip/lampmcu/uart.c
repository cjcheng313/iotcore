#include "SWM201.h"
#include "string.h"


/************************************************************************
 *  Macro Define
 ************************************************************************/
#define	UART1_SEND_FIFO_SIZE	(128)
#define	UART1_READ_FIFO_SIZE	(256)
#define	UART1_SEND_FIFO_MASK	(UART1_SEND_FIFO_SIZE - 1)
#define	UART1_READ_FIFO_MASK	(UART1_READ_FIFO_SIZE - 1)

/************************************************************************
 *  Buffer and Variable Define
 *  ???????????
 ************************************************************************/
static	uint8_t		uart1SendFIFO[UART1_SEND_FIFO_SIZE + 1];
static	uint8_t		uart1ReadFIFO[UART1_READ_FIFO_SIZE + 1];
static	uint16_t	uart1SendRP, uart1SendWP;
static	uint16_t	uart1ReadRP, uart1ReadWP;
static	uint8_t		uart1Char;

void Uart1Init(void) {
	UART_InitStructure UART_initStruct;
	
	PORT_Init(PORTB, PIN8, PORTB_PIN8_UART1_RX, 1);	//GPIOA.0???UART1 RXD
	PORT_Init(PORTB, PIN7, PORTB_PIN7_UART1_TX, 0);	//GPIOA.1???UART1 TXD
 	
 	UART_initStruct.Baudrate = 115200;
	UART_initStruct.DataBits = UART_DATA_8BIT;
	UART_initStruct.Parity = UART_PARITY_NONE;
	UART_initStruct.StopBits = UART_STOP_1BIT;
	UART_initStruct.RXThreshold = 0;
	UART_initStruct.RXThresholdIEn = 1;
	UART_initStruct.TXThreshold = 3;
	UART_initStruct.TXThresholdIEn = 0;
	UART_initStruct.TimeoutTime = 10;		//10?????????????????????
	UART_initStruct.TimeoutIEn = 1;
 	UART_Init(UART1, &UART_initStruct);
	UART_Open(UART1);	
	
	uart1SendRP = 0;
	uart1SendWP = 0;
	uart1ReadRP = 0;
	uart1ReadWP = 0;
}

// Function Transmits Character from RXTXData Buffer
static void uart1SendChar(uint8_t tchar)
{
	UART_WriteByte(UART1, tchar);
	
	while(UART_IsTXBusy(UART1));
}

static uint8_t uart1SendEmpty(void)
{
	return (uart1SendWP == uart1SendRP);
}

void uart1Send(uint8_t *a, uint8_t n)
{
	if (n == 0 || n >= UART1_SEND_FIFO_SIZE)
		return;

	while (n > 0) {
		uart1SendFIFO[uart1SendWP++] = *a++;
		uart1SendWP &= UART1_SEND_FIFO_MASK;
		n--;
	}
}

void UART1_Handler(void)
{
	uint32_t chr;
	
#if 1
	if(UART_INTRXThresholdStat(UART1) || UART_INTTimeoutStat(UART1))
	{
		while(UART_IsRXFIFOEmpty(UART1) == 0)
		{
			if(UART_ReadByte(UART1, &chr) == 0)
			{
				uart1ReadFIFO[uart1ReadWP] = chr;    //???????? 
				uart1ReadWP++;
				uart1ReadWP &= UART1_READ_FIFO_MASK;				
			}
		}
	}
#else
	if(UART_INTRXThresholdStat(UART1))
	{
		while((UART1->FIFO & UART_FIFO_RXLVL_Msk) > 1)
		{
			if(UART_ReadByte(UART1, &chr) == 0)
			{
				uart1ReadFIFO[uart1ReadWP] = chr;    //???????? 
				uart1ReadWP++;
				uart1ReadWP &= UART1_READ_FIFO_MASK;
			}
		}
	}
	else if(UART_INTTimeoutStat(UART1))
	{
		while(UART_IsRXFIFOEmpty(UART1) == 0)
		{
			if(UART_ReadByte(UART1, &chr) == 0)
			{
				uart1ReadFIFO[uart1ReadWP] = chr;    //???????? 
				uart1ReadWP++;
				uart1ReadWP &= UART1_READ_FIFO_MASK;
			}
		}
	}
#endif
}

uint16_t uart1Read(uint8_t *a, uint16_t n)
{
	uint16_t		s = 0;

	while ((n > 0) && (uart1ReadWP != uart1ReadRP)) {
		*a = uart1ReadFIFO[uart1ReadRP];
		*a++;
		uart1ReadRP++;
		uart1ReadRP &= UART1_READ_FIFO_MASK;
		s++;
		n--;
	}

	return s;
}

void UartTimer1Ms(void) {

}

void pollingUart1(void)
{
	if (uart1SendEmpty() == 0) {		
		uart1Char = uart1SendFIFO[uart1SendRP++];
		uart1SendRP &= UART1_SEND_FIFO_MASK;
		uart1SendChar(uart1Char);
	}	
}


