#ifndef	_UART_H
#define	_UART_H

extern	void 	Uart1Init(void);
extern	void 	UartTimer1Ms(void);
extern	void 	uart1Send(uint8_t *a, uint8_t n);
extern	uint16_t uart1Read(uint8_t *a, uint16_t n);
extern	void 	pollingUart1(void);
	
#endif
