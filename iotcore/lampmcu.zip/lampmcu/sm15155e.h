#ifndef	_SM15155E_H
#define	_SM15155E_H

extern	void 	Sm15155Init(void);
extern	void 	Sm15155eStart(void);
extern	void 	Sm15155eStop(void);

extern	void 	Sm15155eTimer1Ms(void);

extern	void 	Sm15155eUpdateData(uint32_t bright, uint32_t color);

#endif
