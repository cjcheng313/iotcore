#ifndef __KEY_H__
#define __KEY_H__


extern 	void 	KeyInit(void);
extern 	void 	KeyTimer1Ms(void);
extern 	void 	pollingKey(void);



#endif
