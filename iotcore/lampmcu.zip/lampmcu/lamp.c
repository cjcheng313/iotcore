#include "stdlib.h"
#include "SWM201.h"
#include "sm15155e.h"
#include "makedef.h"
#include "lamp.h"
#include "ad.h"
#include "ali.h"
#include "mix.h"
#include "makedef.h"

#ifdef	SUPPORT_LAMP_MBI6023
#include "mbi6023.h"
#else
#include "color5.h"
#endif


static 	uint8_t		lampState;
static 	uint32_t	lampTimer;

uint8_t		lampMusicFlag;
uint8_t		lampMusicData;

uint8_t		lampUpdateFlag;
uint8_t		lampBrightValue;
uint16_t	lampWhiteValue;
uint16_t	lampYellowValue;
uint32_t	lampColorValue = 0xff850d;
uint8_t		lampSwitchValue;

#define		BREATH_STEP_MAX		100
uint8_t		lampBreathFlag;
uint8_t		lampBreathStep;
uint8_t		lampBreathDir;
uint32_t	lampBreathColorHead;
uint32_t	lampBreathColorOver;

uint8_t		lampShineFlag;
uint8_t		lampShineMode;
uint8_t		lampShineState;
uint32_t	lampShineColor;

uint8_t		lampWaterFlag;
uint8_t		lampWaterIndex;

uint8_t		lampDynamicFlag;
uint8_t		lampDynamicIndex;

uint8_t		lampPaletteFlag;


enum {
	STATE_IDLE = 0,
	STATE_MUSIC,
	STATE_UPDATE,
	STATE_BREATH,
	STATE_SHINE,
	STATE_WATER,
	STATE_DYNAMIC,
	STATE_PALETTE
};

/*
red 		#FF0000 
oragange 	#FF7F00
yellow 		#FFFF00 
green 		#00FF00 
cyan		#00FFFF 
blue		#0000FF
purple		#8B00FF
*/
COLOR_5 musicColorTbl[7] = {
	{0xff, 0x00, 0x00, 0x00, 0x00},
	{0xff, 0x7f, 0x00, 0x00, 0x00},
	{0xff, 0xff, 0x00, 0x00, 0x00},
	{0x00, 0xff, 0x00, 0x00, 0x00},
	{0x00, 0xff, 0xff, 0x00, 0x00},
	{0x00, 0x00, 0xff, 0x00, 0x00},
	{0x8b, 0x00, 0xff, 0x00, 0x00},	
};

COLOR_5 LampColorOff = {0, 0, 0, 0, 0};


COLOR_5	LampColorBuff[2 * IC_MAX];

void LampInit(void) {
#ifdef	SUPPORT_LAMP_MBI6023
	MBI6023Init();	
#else
	Color5Init();
#endif
	
	lampState = 0;
	lampTimer = 1000;
	
	lampUpdateFlag = 1;
	lampBrightValue = 0x0;
	lampWhiteValue = 0;
	lampYellowValue = 0;
	lampSwitchValue = 1;
	
	lampShineFlag = 0;	
	lampDynamicFlag = 0;
	lampPaletteFlag = 0;

	lampMusicFlag = 0;
	lampBreathFlag = 0;
	lampWaterFlag = 0;
}

void LampUpdateOsd(uint16_t *data) {
	//	0	1	2	3	4	5	6	7	8	9	10	11
	//	y1	g1	r1	b1	w1		y2	g2	r2	b2	w2
#ifdef	SUPPORT_LAMP_MBI6023	
	uint8_t		i;
	
	for (i = 0; i < IC_MAX * 2; i++) {
		data[6 * i + 0] = LampColorBuff[i].y * 655;
		data[6 * i + 1] = LampColorBuff[i].g * 256;
		data[6 * i + 2] = LampColorBuff[i].r * 256;
		data[6 * i + 3] = LampColorBuff[i].b * 256;
		data[6 * i + 4] = LampColorBuff[i].w * 655;
		data[6 * i + 5] = 0;
	}
	MBI6023_Senddata(IC_MAX);
#else
	data[0] = LampColorBuff[0].r;
	data[1] = LampColorBuff[0].g;
	data[2] = LampColorBuff[0].b;
	data[3] = LampColorBuff[0].w;
	data[4] = LampColorBuff[0].y;
	// display
#endif
}

void LampPrepareData(uint8_t ind, uint32_t rgb, uint8_t w, uint8_t y) {
	if (ind < IC_MAX * 2) {
		LampColorBuff[ind].r = (rgb >> 16) & 0xFF;
		LampColorBuff[ind].g = (rgb >> 8) & 0xFF;
		LampColorBuff[ind].b = (rgb) & 0xFF;
		LampColorBuff[ind].w = w;
		LampColorBuff[ind].y = y;
	}
}

void LampPrepareDataUint32(uint32_t color, uint8_t bright, uint16_t white,uint16_t yellow) {
	uint8_t		i;
	white = white*bright/100;
	yellow = yellow*bright/100;
	
	int c[5]={0,0,0,0,0};
	
	int r = (color >> 16) & 0xFF;	
	int g = (color >> 8) & 0xFF;	
	int b = (color) & 0xFF;
	if(color!=0){
		colormixsimple(r,g,b,c);
		white = c[3];
		yellow = c[4];
	}
	for (i = 0; i < IC_MAX*2; i++) {
		LampColorBuff[i].r = r;	
		LampColorBuff[i].g = g;	
		LampColorBuff[i].b = b;

		LampColorBuff[i].w = white%101;
		LampColorBuff[i].y = yellow % 101;
	}		
}

void LampMusicUpdate(void) {
	uint8_t		i;
	uint16_t	s = 2000, e = 4000;
	uint8_t		level;

	if (adValue <= s) level = 0;
	else if (adValue >= e) level = IC_MAX * 2 - 1;
	else {
		level = (adValue - s) * (IC_MAX * 2) / (e - s);
	}
	
	for (i = 0; i < IC_MAX*2; i++) {
		if (i <= level)
			LampColorBuff[i] = musicColorTbl[i % 7];	
		else
			LampColorBuff[i] = LampColorOff;	
	}

	LampUpdateOsd(OsdColorBuffer);
}

void LampBasicUpdate(void) {

	if (lampSwitchValue) {
		LampPrepareDataUint32(lampColorValue, lampBrightValue, lampWhiteValue, lampYellowValue);
	}
	else {
		LampPrepareDataUint32(0x0, 0, 0,0);
	}

	LampUpdateOsd(OsdColorBuffer);
}

void LampBreathUpdate(void) {
	LampPrepareDataUint32(lampBreathColorHead, lampBreathStep / 2, lampBreathStep / 2,lampBreathStep / 2);

	LampUpdateOsd(OsdColorBuffer);
}

void LampShineUpdate(void) {

	if (lampShineState) {
		LampPrepareDataUint32(lampShineColor, lampBrightValue, lampWhiteValue, lampYellowValue);
	}
	else {
		LampPrepareDataUint32(0x0, 0, 0,0);
	}

	LampUpdateOsd(OsdColorBuffer);	
}

void LampWaterUpdate(void) {
	uint8_t		i;
	
	if (lampWaterIndex >= IC_MAX * 2) lampWaterIndex = 0;
	
	for (i = 0; i < IC_MAX * 2; i++) {
		if (i == lampWaterIndex)
			LampPrepareData(i, 0xff0000, 5, 5);
		else
			LampPrepareData(i, 0x000000, 5, 5);			
	}

	LampUpdateOsd(OsdColorBuffer);	
}

uint32_t LampGetMidColor(uint32_t color0, uint32_t color1, uint16_t ind, uint16_t total) {
	uint32_t	s, e, m;
	uint32_t	ret = 0x000000;

	s = (color0 >> 16) & 0xFF;
	e = (color1 >> 16) & 0xFF;
	if (s > e) {		
		m = s - (s - e) * ind / total;
	}
	else {
		m = s + (e - s) * ind / total;
	}
	ret += m;
	ret <<= 8;
	
	s = (color0 >> 8) & 0xFF;
	e = (color1 >> 8) & 0xFF;
	if (s > e) {		
		m = s - (s - e) * ind / total;
	}
	else {
		m = s + (e - s) * ind / total;
	}
	ret += m;
	ret <<= 8;
	
	s = (color0) & 0xFF;
	e = (color1) & 0xFF;
	if (s > e) {		
		m = s - (s - e) * ind / total;
	}
	else {
		m = s + (e - s) * ind / total;
	}
	ret += m;
	
	return ret;
}

void LampDynamicUpdate(uint8_t ind, uint16_t total) {
	uint8_t		i;
	uint32_t	color_head, color_tail, color_now;
	
	if (SceneData.total == 0) return;
	if (lampDynamicIndex >= SceneData.total - 1) lampDynamicIndex = 0;
	
	if (ind >= total) ind = 0;
	if (lampDynamicIndex == SceneData.total - 1) {
		color_now = SceneData.color[lampDynamicIndex];
	}
	else {
		color_head = SceneData.color[lampDynamicIndex];
		color_tail = SceneData.color[lampDynamicIndex + 1];
		color_now = LampGetMidColor(color_head, color_tail, ind, total);		
	}
	
	for (i = 0; i < IC_MAX * 2; i++) {
		LampPrepareData(i, color_now, 0, 0);
	}

	LampUpdateOsd(OsdColorBuffer);
}

void LampPaletteUpdate() {
	uint8_t		i, j;
	
	if (PaletteData.total == 0) return;
	for (i = 0; i < IC_MAX * 2; i++) {
		for (j = 0; j < PaletteData.total; j++) {
			if (PaletteData.id[j] == i) break;
		}
		if (j >= PaletteData.total) {
			LampPrepareData(i, 0x0, 0, 0);
		}
		else {
			LampPrepareData(i, PaletteData.rgb[j], 0, 0);
		}
	}
	LampUpdateOsd(OsdColorBuffer);	
}

void lampStartShine(uint32_t color) {
	lampShineFlag = 1;
	lampShineColor = color;
	lampShineMode = 0;
}

void lampStopShine(void)
{
	lampShineFlag = 0;
}

void lampColorPlus(void) {
	if (lampWhiteValue < 100) {
		lampWhiteValue += 10;
		if (lampWhiteValue > 100) lampWhiteValue = 100;
		lampUpdateFlag = 1;
	}
}

void lampColorMinus(void) {
	if (lampWhiteValue > 10) {
		lampWhiteValue -= 10;
		lampUpdateFlag = 1;
	}
	else if (lampWhiteValue > 0) {
		lampWhiteValue = 0;
		lampUpdateFlag = 1;
	}
}

void lampBrightPlus(void) {
	if (lampBrightValue < 100) {
		lampBrightValue += 10;
		if (lampBrightValue > 100) lampBrightValue = 100;
		lampUpdateFlag = 1;
	}
}

void lampBrightMinus(void) {
	if (lampBrightValue > 10) {
		lampBrightValue -= 10;
		lampBrightValue = 1;
	}
	else if (lampBrightValue > 0) {
		lampBrightValue = 0;
		lampUpdateFlag = 1;
	}
}


void LampTimer1Ms(void) {
	if (lampTimer)	lampTimer--;

}

void pollingLamp(void) {
	switch (lampState) {
		case STATE_IDLE:
			if (lampDynamicFlag) {
				lampDynamicIndex = 0;
				lampState = STATE_DYNAMIC;
			}
			else if (lampShineFlag) {
				lampState = STATE_SHINE;
			}
			else if (lampUpdateFlag) {
				lampUpdateFlag = 0;
				lampState = STATE_UPDATE;
			}
			else if (lampPaletteFlag) {
				lampPaletteFlag = 0;
				lampState = STATE_PALETTE;
			}
			else if (lampMusicFlag) {
				lampDynamicFlag = 0;
				adWorkFlag = 1;
				lampState = STATE_MUSIC;
			}
			

			else if (lampBreathFlag) {
				lampState = STATE_BREATH;
			}
			else if (lampWaterFlag) {
				lampWaterIndex = 0;
				lampState = STATE_WATER;
			}
			break;
			
			
		case STATE_UPDATE:
			LampBasicUpdate();
			lampState = STATE_IDLE;
			break;
		
		case STATE_DYNAMIC:
			//if (lampTimer) break;
			if (!lampDynamicFlag) {
				lampState = STATE_IDLE;				
			}
			else {
				if (lampTimer % 20 == 0) {
					LampDynamicUpdate(SceneData.intervalTimes[lampDynamicIndex] / 20 - lampTimer / 20, SceneData.intervalTimes[lampDynamicIndex] / 20);
					if (lampTimer == 0) {
						lampDynamicIndex++;				
						lampTimer = SceneData.intervalTimes[lampDynamicIndex];
						if (lampDynamicIndex >= SceneData.total - 1) {
							lampDynamicIndex = 0;
							if (SceneData.showTimes) {
								SceneData.showTimes--;
								if (SceneData.showTimes == 0) {
									lampDynamicFlag = 0;
								}
							}
						}
					}					
				}
			}
			break;

		case STATE_SHINE:
			if (lampTimer) break;
			if (!lampShineFlag) {
				lampUpdateFlag = 1;
				lampState = STATE_IDLE;
				break;
			}
			
			if (lampShineMode) lampTimer = 1000;
			else lampTimer = 500;
			if (lampShineState) {
				lampShineState = 0;
				LampShineUpdate();
			}
			else {
				lampShineState = 1;
				LampShineUpdate();
			}
			break;

		case STATE_PALETTE:
			LampPaletteUpdate();
			lampState = STATE_IDLE;
			break;			

		case STATE_MUSIC:
			if (lampTimer) break;
			lampTimer = 50;
			if (!lampMusicFlag) {
				adWorkFlag = 0;
				lampState = STATE_IDLE;			
			}
			else {
				LampMusicUpdate();
			}
			lampState = STATE_IDLE;			
			break;
			
			
			
		
		case STATE_BREATH:
			if (lampTimer) break;
			if (lampBreathFlag == 0) {
				lampState = STATE_IDLE;
				break;
			}
			if (lampBreathDir) {
				if (++lampBreathStep >= BREATH_STEP_MAX) {
					lampBreathDir = 0;
				}
			}
			else {
				if (--lampBreathStep <= 1) {
					lampBreathDir = 1;
				}
			}				
			LampBreathUpdate();
			lampTimer = 10;
			break;
			
		case STATE_WATER:
			if (lampTimer) break;
			lampTimer = 100;
			if (!lampWaterFlag) {
				lampState = STATE_IDLE;
			}
			else {
				LampWaterUpdate();			
				lampWaterIndex++;
				if (lampWaterIndex >= IC_MAX * 2) lampWaterIndex = 0;	
			}				
			break;
		
			
	}
}

uint8_t	testind = 0;
void testlamp(void) {
	lampWaterFlag = 1;	
	return;
	if (testind == 0) {
		lampShineFlag = 1;
		lampShineColor = 0xFF0000;
		lampShineMode = 0;
		testind++;
	}
	else if (testind ==1) {
		lampShineColor = 0x00ff00;
		testind++;
	}
	else if (testind == 2) {
		testind++;
		lampShineFlag = 0;
		
		lampBreathFlag = 1;
		lampBreathStep = 0;
		lampBreathDir = 1;
		lampBreathColorHead = 0xff9900;
		lampBreathColorOver = 0xff9900;
	}
	else if (testind==3) {
		lampBreathFlag = 0;
		testind++;
	}
	else if (testind==4){
		testind++;
		LampPrepareData(0, 0xff0000, 0, 0);
		LampPrepareData(1, 0xff00, 0, 0);
		LampPrepareData(2, 0xff, 0, 0);
		LampPrepareData(3, 0xffff, 0, 0);
		LampPrepareData(4, 0xffff00, 0, 0);
		LampPrepareData(5, 0xff00ff, 0, 0);
		LampUpdateOsd(OsdColorBuffer);
	}
	else if (testind==5){
		testind++;
		lampWaterFlag = 1;		
	}
	else {
		testind = 0;
		lampWaterFlag = 0;
		lampState = STATE_IDLE;
	}
	
	return;
	
	switch(testind) {
		case 0:
			lampUpdateFlag = 1;
			lampBrightValue = 50;
			lampColorValue = 0xFF0000;
			lampSwitchValue = 1;
			testind++;
			break;
	
		case 1:
			lampUpdateFlag = 1;
			lampBrightValue = 50;
			lampColorValue = 0xff00;
			lampSwitchValue = 1;
			testind++;
			break;
	
		case 2:
			lampUpdateFlag = 1;
			lampBrightValue = 50;
			lampColorValue = 0xFF;
			lampSwitchValue = 1;
			testind++;
			break;
		
		case 3:
			lampUpdateFlag = 1;
			lampSwitchValue = 0;
			testind++;
			break;
		
		case 4:
			adWorkFlag = 1;
			testind++;
			break;
		
		case 5:
			adWorkFlag = 0;
			testind++;
			break;
		
		case 6:
			lampBreathFlag = 1;
			lampBreathStep = 0;
			lampBreathDir = 1;
			lampBreathColorHead = 0xff0022;
			lampBreathColorOver = 0xff0022;
			testind++;
			break;
		
		case 7:
			lampBreathFlag = 0;
			testind++;
			break;
		
		default:
			testind = 0;
			break;
	}

}
