#include "SWM201.h"
#include "led.h"
#include "key.h"
#include "lamp.h"
#include "uart.h"
#include "ali.h"
#include "lamp.h"
#include "ad.h"
#include "timer.h"


uint32_t Timer1Ms;

void SysTick_Handler(void)
{	
	Timer1Ms++;
}

void PollingTimer(void) {
	if (Timer1Ms) {
		Timer1Ms = 0;
		
		LedTimer1Ms();
		
		KeyTimer1Ms();
		UartTimer1Ms();
		AliTimer1Ms();
		LampTimer1Ms();
		AdTimer1Ms();
		
	}
}


int main(void)
{	
	//uint32_t a = SYS->CHIPID[0];
	//uint32_t b = SYS->CHIPID[1];
	//uint32_t c = SYS->CHIPID[2];

	Timer1Ms = 0;
	
	
	SystemInit();
	SysTick_Config(SystemCoreClock/1000);			//1Ms
	
	TimerInit();
	LedInit();
	KeyInit();
	Uart1Init();
	AliInit();
	LampInit();
	AdInit();
	
	while (1==1) {
		//extern void testad(void); testad();
		PollingTimer();
		
		PollingLed();
		pollingKey();
		pollingUart1();
		pollingAli();
		pollingLamp();
		pollingAd();
	}
}
