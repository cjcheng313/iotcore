#include "string.h"
#include "SWM201.h"
#include "makedef.h"
#include "led.h"
#include "lamp.h"
#include "ad.h"
#include "ali.h"



#ifdef	NEW_BBB
#define	KEY_GPIO		GPIOA			//INPUT, pullup
#define	KEY_PIN			PIN10
#else
#define	KEY_GPIO		GPIOA			//INPUT, pullup
#define	KEY_PIN			PIN3
#endif
#define	KEY_IN			(GPIO_GetBit(KEY_GPIO, KEY_PIN) == 0)


#define	KEY_COLOR_PLUS_GPIO		GPIOA
#define	KEY_COLOR_PLUS_PIN		PIN2
#define	KEY_COLOR_MINUS_GPIO	GPIOA
#define	KEY_COLOR_MINUS_PIN		PIN0
#define	KEY_BRIGHT_PLUS_GPIO	GPIOA
#define	KEY_BRIGHT_PLUS_PIN		PIN9
#define	KEY_BRIGHT_MINUS_GPIO	GPIOA
#define	KEY_BRIGHT_MINUS_PIN	PIN1

#define	KEY_COLOR_PLUS_IN			(GPIO_GetBit(KEY_COLOR_PLUS_GPIO, KEY_COLOR_PLUS_PIN) == 0)
#define	KEY_COLOR_MINUS_IN			(GPIO_GetBit(KEY_COLOR_MINUS_GPIO, KEY_COLOR_MINUS_PIN) == 0)
#define	KEY_BRIGHT_PLUS_IN			(GPIO_GetBit(KEY_BRIGHT_PLUS_GPIO, KEY_BRIGHT_PLUS_PIN) == 0)
#define	KEY_BRIGHT_MINUS_IN			(GPIO_GetBit(KEY_BRIGHT_MINUS_GPIO, KEY_BRIGHT_MINUS_PIN) == 0)

#define	KEY_CHECK		3

enum {
	KEY_MAIN,
	KEY_COLOR_PLUS,
	KEY_COLOR_MINUS,
	KEY_BRIGHT_PLUS,
	KEY_BRIGHT_MINUS,
	KEY_MAX	
};

static 	uint8_t		keyState;
static 	uint32_t	keyTimer;

static	uint8_t		keyValue;
static	uint8_t		keyRead;
static	uint8_t		keySave;

static	uint8_t		keyCheck;

void KeyInit(void) {
	GPIO_Init(KEY_GPIO, KEY_PIN, 0, 1, 0, 0);			//INPUT, pullup
	
	GPIO_Init(KEY_COLOR_PLUS_GPIO, KEY_COLOR_PLUS_PIN, 0, 1, 0, 0);			//INPUT, pullup
	GPIO_Init(KEY_COLOR_MINUS_GPIO, KEY_COLOR_MINUS_PIN, 0, 1, 0, 0);			//INPUT, pullup
	GPIO_Init(KEY_BRIGHT_PLUS_GPIO, KEY_BRIGHT_PLUS_PIN, 0, 1, 0, 0);			//INPUT, pullup
	GPIO_Init(KEY_BRIGHT_MINUS_GPIO, KEY_BRIGHT_MINUS_PIN, 0, 1, 0, 0);			//INPUT, pullup

	keyTimer = 0;
	keyState = 0;
	keyCheck = 0;
}

uint8_t keyScan(void) {
	
	if (KEY_COLOR_PLUS_IN) {	// key3
		return KEY_COLOR_PLUS;
	}
	else
	if (KEY_COLOR_MINUS_IN) {	// key5
		return KEY_COLOR_MINUS;
	}
	else
	if (KEY_BRIGHT_PLUS_IN) {	// key1
		return KEY_BRIGHT_PLUS;
	}
	else
	if (KEY_BRIGHT_MINUS_IN) {	// key4
		return KEY_BRIGHT_MINUS;
	}
	else if (KEY_IN) {
		return KEY_MAIN;
	}
	return KEY_MAX;
}

static void KeyFunction(void) {
	LedWork(1);
	
	switch(keyValue) {
		case KEY_MAIN:		// match...
			//matchFlag = 1;
			{extern void getMac(); getMac();}
			break;
		case KEY_COLOR_PLUS:
			lampColorPlus();
			break;
		case KEY_COLOR_MINUS:
			lampColorMinus();
			break;
		case KEY_BRIGHT_PLUS:
			lampBrightPlus();
			break;
		case KEY_BRIGHT_MINUS:
			lampBrightMinus();
			break;
	}
		
#if 0	
	//{extern uint8_t matchFlag; matchFlag = 1;}
	//{extern void testlamp(void);testlamp();}
	//{extern void getMac(); getMac();	}
	//{extern void sendRst(); sendRst();	}
	

	{
		//extern	void uartSend(unsigned char *data);
		//uartSend("AT+GMR\r\n");
		//extern void uart1Send(uint8_t*, uint8_t);
	//uart1Send("AT+GMR\n\r", 8);
//uart1Send("AT+RST\n\r", 8);	
//uart1Send("AT+RECVJSON\n\r", 13);	
		
		//extern void AliProJson(char *buff, uint8_t len);
		//AliProJson("{\"brightValue\":100,\"colourDate\":\"99ffff\",\"switchMode\":2}", 56);
		
	
		//lampSwitchValue = 1;
		//lampColorValue = 0xFF0000;
		//lampBrightValue = 50;
		//lampUpdateFlag = 1;
		
		{
			//adWorkFlag = 1;
			//extern void testad(void); testad();
			
			//lampBreathFlag = 1;
			//lampBreathStep = 0;
			//lampBreathSum = 20;
		}
	}
#endif
}

void KeyTimer1Ms(void) {
	if (keyTimer)	keyTimer--;
}


void pollingKey(void) {
	switch (keyState) {
	case 0:
		if (keyTimer) break;
		keyRead = keyScan();
		if (keyRead < KEY_MAX) {
			keySave = keyRead;
			keyState++;	
			keyCheck = 0;
		}
		break;

	case 1:
		if (keyTimer) break;
		keyRead = keyScan();
		if (keyRead == keySave) {
			if (keyCheck++ > KEY_CHECK) {
				keyValue = keyRead;
				KeyFunction();

				keyState = 0;
				keyTimer = 500;
			}
			else {
				keyTimer = 20;
			}
		}
		else if (keyRead < KEY_MAX) {
			keyTimer = 20;
			keySave = keyRead;
			keyCheck = 0;
		}
		else  {
			keyState = 0;
		}
		break;

	default:
		keyState = 0;
		break;
	}
}

