#include "SWM201.h"
#include "led.h"
#include "lamp.h"
#include "uart.h"
#include "lamp.h"
#include <stdlib.h>

uint8_t		adWorkFlag;
uint8_t		adState;
uint32_t	adTimer;

uint16_t	adValue;

/* ????:SWM201 ADC ?? Continue ??????????:
 * 1?ADC_initStruct.trig_src ?????? 0 ,??? ADC_TRIGGER_SW
 * 2??? ADC ????? ADC0->START = 1; ???? ADC_Start(ADC0);
 * 3?Continue ????? TIMR ???PWM ??????,???????
 *****************************************************************************/
 

void AdInit(void) {
	ADC_InitStructure ADC_initStruct;
	
	PORT_Init(PORTB, PIN9,  PORTB_PIN9_ADC0_CH8,  0);		//PB.9  => ADC0.CH8
	
	ADC_initStruct.clk_src = ADC_CLKSRC_HRC_DIV8;
	ADC_initStruct.clk_div = 15;
	ADC_initStruct.ref_src = ADC_REFSRC_VDD;	//ADC_REFSRC_VDD;	//ADC_REFSRC_VREFP;
	ADC_initStruct.channels = ADC_CH8;
	ADC_initStruct.samplAvg = ADC_AVG_SAMPLE1;
	ADC_initStruct.trig_src = ADC_TRIGGER_SW;
	ADC_initStruct.Continue = 0;						//?????,?????
	ADC_initStruct.EOC_IEn = 0;	
	ADC_initStruct.OVF_IEn = 0;
	ADC_Init(ADC0, &ADC_initStruct);					//??ADC
	
	ADC_Open(ADC0);										//??ADC
	
	
	adWorkFlag = 0;
	adState = 0;
	adTimer = 0;
}

#if 0
uint16_t Buffer[1000] = {0};
uint32_t	vv=0;
void testad(void) {
	uint32_t	i;
	
		
		for(i = 0; i < 1000000; i++)
		{
			ADC_Start(ADC0);
			while((ADC0->CH[8].STAT & ADC_STAT_EOC_Msk) == 0);
			ADC0->CH[8].STAT = (1 << ADC_STAT_EOC_Pos);
			adValue = ADC0->CH[8].DATA & ADC_DATA_VAL_Msk;
			vv = (uint32_t)adValue * 33 / 4096;
			ADC_Stop(ADC0);
		}

		
}
#endif

void AdTimer1Ms(void) {
	if (adTimer)	adTimer--;
}

void pollingAd(void) {
	switch (adState) {
	case 0:
		if (adWorkFlag) {
			adState++;
		}
		break;
		
	case 1:
		if (adTimer) break;
		ADC_Start(ADC0);
		adTimer = 3;
		adState++;
		break;
	case 2:
		if (adTimer) break;
		if (adWorkFlag == 0) {			
			adState = 0;			
		}
		else if ((ADC0->CH[8].STAT & ADC_STAT_EOC_Msk) != 0) {
			ADC0->CH[8].STAT = (1 << ADC_STAT_EOC_Pos);
			adValue = ADC0->CH[8].DATA & ADC_DATA_VAL_Msk;
			//int a = rand() % 2000;
			//adValue = 2000+a; 
			adTimer = 20;
			adState--;
		}
		ADC_Stop(ADC0);
		break;
		
	default:
		adState = 0;
		adWorkFlag = 0;
		break;	
		
	}
	
}

