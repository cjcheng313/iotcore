#include "SWM201.h"
#include "color5.h"

void TimerInit(void) {
	TIMR_Init(TIMR0, TIMR_MODE_TIMER, CyclesPerUs / 10, 10, 1);		// 1us
	TIMR_Start(TIMR0);
}

void TIMR0_Handler(void)
{
	TIMR_INTClr(TIMR0);
	
	Color5Irq();


	
}