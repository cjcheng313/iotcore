#ifndef __MBI6023_H__
#define __MBI6023_H__

#ifdef	SUPPORT_LAMP_MBI6023
extern uint16_t	OsdColorBuffer[];

typedef enum 
{
	MBI6023_Grey_16bit,
	MBI6023_Grey_10bit
}MBI6023_Grey;

typedef struct {
	uint16_t Driver_num;
	MBI6023_Grey Grey_Level;
	uint16_t MBI6023_Header[3];
}MBI6023_Chip;


extern 	void 	MBI6023Init(void);
extern 	void 	MBI6023Timer1Ms(void);
extern 	void 	pollingMBI6023(void);

extern	void MBI6023_Senddata(uint8_t num);

#endif

#endif
