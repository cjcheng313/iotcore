#include "string.h"
#include "SWM201.h"
#include "makedef.h"


#define	COLOR_R_GPIO	GPIOA
#define	COLOR_R_PIN		PIN3
#define	COLOR_G_GPIO	GPIOA
#define	COLOR_G_PIN		PIN5
#define	COLOR_B_GPIO	GPIOA
#define	COLOR_B_PIN		PIN12
#define	COLOR_W_GPIO	GPIOA
#define	COLOR_W_PIN		PIN4
#define	COLOR_Y_GPIO	GPIOM
#define	COLOR_Y_PIN		PIN9


uint16_t	OsdColorBuffer[5];


uint8_t	timerUnit;

void Color5Init(void) {
	GPIO_Init(COLOR_R_GPIO, COLOR_R_PIN, 1, 0, 0, 0);			// output, no pulldown, no pullup, no opendrain
	GPIO_ClrBit(COLOR_R_GPIO, COLOR_R_PIN);
	GPIO_Init(COLOR_G_GPIO, COLOR_G_PIN, 1, 0, 0, 0);			// output, no pulldown, no pullup, no opendrain
	GPIO_ClrBit(COLOR_G_GPIO, COLOR_G_PIN);
	GPIO_Init(COLOR_B_GPIO, COLOR_B_PIN, 1, 0, 0, 0);			// output, no pulldown, no pullup, no opendrain
	GPIO_ClrBit(COLOR_B_GPIO, COLOR_B_PIN);
	GPIO_Init(COLOR_W_GPIO, COLOR_W_PIN, 1, 0, 0, 0);			// output, no pulldown, no pullup, no opendrain
	GPIO_ClrBit(COLOR_W_GPIO, COLOR_W_PIN);
	GPIO_Init(COLOR_Y_GPIO, COLOR_Y_PIN, 1, 0, 0, 0);			// output, no pulldown, no pullup, no opendrain
	GPIO_ClrBit(COLOR_Y_GPIO, COLOR_Y_PIN);	
	
	memset(OsdColorBuffer, 0, 5);
	timerUnit = 0;
}

void Color5Irq(void) {
	timerUnit++;
	if (timerUnit >= 0xFF) timerUnit = 0;
	
	if (timerUnit <= OsdColorBuffer[0])
		GPIO_SetBit(COLOR_R_GPIO, COLOR_R_PIN);
	else
		GPIO_ClrBit(COLOR_R_GPIO, COLOR_R_PIN);
	
	if (timerUnit <= OsdColorBuffer[1])
		GPIO_SetBit(COLOR_G_GPIO, COLOR_G_PIN);
	else
		GPIO_ClrBit(COLOR_G_GPIO, COLOR_G_PIN);
	
	if (timerUnit <= OsdColorBuffer[2])
		GPIO_SetBit(COLOR_B_GPIO, COLOR_B_PIN);
	else
		GPIO_ClrBit(COLOR_B_GPIO, COLOR_B_PIN);

	if (timerUnit <= OsdColorBuffer[2])
		GPIO_SetBit(COLOR_W_GPIO, COLOR_W_PIN);
	else
		GPIO_ClrBit(COLOR_W_GPIO, COLOR_W_PIN);
	
	if (timerUnit <= OsdColorBuffer[2])
		GPIO_SetBit(COLOR_Y_GPIO, COLOR_Y_PIN);
	else
		GPIO_ClrBit(COLOR_Y_GPIO, COLOR_Y_PIN);	

}

