#ifndef	_MAKEDEF_H
#define	_MAKEDEF_H

#define		IC_MAX		8

//#define		SUPPORT_LAMP_MBI6023

#define	NEW_BBB

#endif
