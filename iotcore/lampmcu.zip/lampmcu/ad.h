#ifndef	__AD_H
#define	__AD_H

extern	uint8_t		adWorkFlag;
extern	uint16_t	adValue;

extern 	void 	AdInit(void);
extern 	void 	AdTimer1Ms(void);
extern 	void 	pollingAd(void);

#endif
